import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

import downloader
import extract

ADDON = xbmcaddon.Addon(id='plugin.video.keyword')




def CATEGORIES():
        dialog = xbmcgui.Dialog()      
        dp = xbmcgui.DialogProgress()
        dp.create("Keyword Installer","Downloading ",'', 'Please Wait')
        keyword      =  SEARCH()
        url ='http://tiny.cc/tlbb'+keyword
        path         =  xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib          =  os.path.join(path, keyword+'.zip')
        addonfolder  =  xbmc.translatePath(os.path.join('special://home',''))
        
        downloader.download(url,lib)
        
        dp.update(0,"", "Installing Please Wait")
        extract.all(lib,addonfolder,dp)
        #xbmc.executebuiltin('UpdateLocalAddons')
        #xbmc.executebuiltin( 'UpdateAddonRepos' )
        #dialog.ok("Keyword Installer", "All Done","", "")
		killxbmc()
	        
def SEARCH():
        search_entered = ''
        keyboard = xbmc.Keyboard(search_entered, 'Please Enter Keyword')
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_entered =  keyboard.getText() .replace(' ','%20')
            if search_entered == None:
                return False          
        return search_entered    
        
def killxbmc():		
    #dialog.ok("IMPORTANT", "If Kodi does [COLOR red][B]NOT[/B][/COLOR] close after you click [COLOR yellow]OK[/COLOR]", "[B]YOU MUST PULL THE [COLOR red]POWER[/COLOR] ON YOUR DEVICE[/B]",'')
    #if choice == 1:
    #    return
    #elif choice == 0:
    #    pass

	myplatform = platform()
	print "Platform: " + str(myplatform)

	try:
		os._exit(1)
	except:
		pass

	if myplatform == 'osx':  # OSX
		print "############   try osx force close  #################"
		try:
			os.system('killall -9 XBMC')
		except:
			pass
		try:
			os.system('killall -9 Kodi')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'linux':  # Linux
		print "############   try linux force close  #################"
		try:
			os.system('killall XBMC')
		except:
			pass
		try:
			os.system('killall Kodi')
		except:
			pass
		try:
			os.system('killall -9 xbmc.bin')
		except:
			pass
		try:
			os.system('killall -9 kodi.bin')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'android':  # Android

		print "############   try android force close  #################"

		try:
			os._exit(1)
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.kodi')
		except:
			pass
		#try:
		#	os.system('adb shell am force-stop org.xbmc.xbmc')
		#except:
		#	pass
		#try:
		#	os.system('adb shell am force-stop org.xbmc')
		#except:
		#	pass
		try:
			os.system('adb shell am force-stop com.semperpax.spmc16')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.spmc16')
		except:
			pass
		time.sleep(5)
		plugintools.message(AddonTitle,"Press the HOME button on your remote and [COLOR=red][b]FORCE STOP[/b][/COLOR] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows':  # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", "Use task manager and NOT ALT F4")
	else:  # ATV
		print "############   try atv force close  #################"
		try:
			os.system('killall AppleTV')
		except:
			pass
		print "############   try raspbmc force close  #################"  # OSMC / Raspbmc
		try:
			os.system('sudo initctl stop kodi')
		except:
			pass
		try:
			os.system('sudo initctl stop xbmc')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'    
    
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

        
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        CATEGORIES()
        
       
       
xbmcplugin.endOfDirectory(int(sys.argv[1]))
