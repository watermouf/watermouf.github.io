import xbmc
osWin = xbmc.getCondVisibility('system.platform.windows')
osOsx = xbmc.getCondVisibility('system.platform.osx')
osLinux = xbmc.getCondVisibility('system.platform.linux')
osAndroid = xbmc.getCondVisibility('System.Platform.Android')
url = 'http://www.google.com/'

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
def platform2():
    if osOsx:    
        # ___ Open the url with the default web browser
        xbmc.executebuiltin("System.Exec(open "+url+")")
    elif osWin:
        # ___ Open the url with the default web browser
        #xbmc.executebuiltin("System.Exec(cmd.exe /c start "+url+")")
		chromelauncher()
    elif osLinux and not osAndroid:
        # ___ Need the xdk-utils package
        xbmc.executebuiltin("System.Exec(xdg-open "+url+")") 
    elif osAndroid:
        # ___ Open media with FileExplorer
        xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop,android.intent.action.VIEW,,"+url+")")
        # ___ Open media with standard android web browser
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        # ___ Open media with FileExplorer
        xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop,android.intent.action.VIEW,,"+url+")")
       # ___ Open media with Mozilla Firefox
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")                    
        # ___ Open media with Chrome
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")")
def chromelauncher():
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.chrome.launcher/?kiosk=no&mode=showSite&stopPlayback=yes&url=http%3a%2f%2fgoogle.com",return)')		